hora = int(input("Digite as horas:"))

if hora > =8 and < = 10:
    print("Bom dia! Você consegue alcançar seus objetivos!")

elif hora > =10 and < = 14:
    print("Hora do almoço! Recarregue suas energias para continuar avançando!")

elif hora > =14 and < = 17:
    print("Boa tarde! Persista nos seus esforços, você está no caminho certo!")
