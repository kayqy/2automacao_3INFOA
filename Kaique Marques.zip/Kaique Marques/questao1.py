#Entrada
n1 = input("Digite o número de copos: ")

#Processamento
ml = int(n1) * 200

#Saída
print("A quantidade de ml é de", n1, "*", 200,"=", ml)
