
n1 = input("Digite o número: ")

tabuada = int(n1) * i

for i in range(100, 0):
    print(i, "repetição decrescente")
print("A tabuada é de", n1, "*", i,"=", tabuada)